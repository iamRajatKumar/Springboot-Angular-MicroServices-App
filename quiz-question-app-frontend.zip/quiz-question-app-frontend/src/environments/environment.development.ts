export const environment = {
    productionL: false,
    apiUrl:'http://localhost:8083'
};

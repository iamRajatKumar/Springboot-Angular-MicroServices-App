export interface Options {
    optionsId?: number;
    text: string;
    correct?: boolean;
}

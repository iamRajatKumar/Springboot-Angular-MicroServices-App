package com.example.QuizService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
